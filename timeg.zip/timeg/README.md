# timeg

A Pen created on CodePen.io. Original URL: [https://codepen.io/ahmed-mk-the-animator/pen/zxOLbJj](https://codepen.io/ahmed-mk-the-animator/pen/zxOLbJj).

يساعد على معرفة عدد ساعات الدراسة