let timer;

let seconds = 0;

let isPaused = false;

let totalTimeInSeconds = 0;

let isDarkMode = false;

const timeDisplay = document.getElementById('timeDisplay');

const studyTimeInput = document.getElementById('studyTime');

const startButton = document.getElementById('startButton');

const pauseButton = document.getElementById('pauseButton');

const resumeButton = document.getElementById('resumeButton');

const resetButton = document.getElementById('resetButton');

function startTimer() {

    const hours = parseInt(studyTimeInput.value);

    if (isNaN(hours) || hours <= 0) return;

    totalTimeInSeconds = hours * 3600;

    isPaused = false;

    updateDisplay();

    startButton.disabled = true;

    pauseButton.disabled = false;

    resumeButton.disabled = false;

    resetButton.disabled = false;

    timer = setInterval(function() {

        if (!isPaused && totalTimeInSeconds > 0) {

            totalTimeInSeconds--;

            updateDisplay();

        }

    }, 1000);

}

function updateDisplay() {

    let hours = Math.floor(totalTimeInSeconds / 3600);

    let minutes = Math.floor((totalTimeInSeconds % 3600) / 60);

    let secondsRemaining = totalTimeInSeconds % 60;

    timeDisplay.textContent = `${pad(hours)}:${pad(minutes)}:${pad(secondsRemaining)}`;

}

function pad(num) {

    return num < 10 ? '0' + num : num;

}

function pauseTimer() {

    isPaused = true;

}

function resumeTimer() {

    isPaused = false;

}

function resetTimer() {

    clearInterval(timer);

    totalTimeInSeconds = 0;

    isPaused = false;

    updateDisplay();

    startButton.disabled = false;

    pauseButton.disabled = true;

    resumeButton.disabled = true;

    resetButton.disabled = true;

}

function toggleTheme() {

    isDarkMode = !isDarkMode;

    if (isDarkMode) {

        document.body.classList.add('dark-mode');

        document.getElementById('themeToggle').textContent = '🌙';

    } else {

        document.body.classList.remove('dark-mode');

        document.getElementById('themeToggle').textContent = '🌞';

    }

}